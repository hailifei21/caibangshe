<template>
	<div>
		<h3>我是注册页</h3>
	</div>
	
</template>

<script>
export default {
	name: 'reg',
	data () {
		return {

		}
	}
}	

</script>
<style >
	body{
    		background:#E1E1E1;
    	}

	
</style>
