<template>
	<div id="content">
		<div class="panel" >
			<div class="list-group">
				<div class="list-group-item" style="background:#F6F6F6" id="tiao">
					<span id="zy"><a href="/">主页</a></span>
					<span class="divider">/</span>
					<span class="active" style="color:#999999">Vue.js参考资料</span>
        		</div>

        		<div class="list-group-item">
        			<h3 style="font-weight:bold;margin-bottom:0.3125rem;margin-top:3.125rem">文档&社区</h3>
				</div>
				<div class="list-group-item" style="color:#999999">
					<p id="w1">
					   <b>·</b>
					   <a href="http://cn.vuejs.org/" target="_blank">Vue.js官方网站（中文）
					   </a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://forum.vuejs.org/" target="_blank">Vue论坛</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://cn.vuejs.org/" target="_blank">Vue.js官方网站（中文）
					   </a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://vuejs.github.io/vue-router/zh-cn/index.html" target="_blank">vue-router</a>
					</p>
					<h3 style="font-weight:bold;color:black;margin-bottom:0.3125rem;margin-top:3.125rem">文章</h3>
				</div>
				<div class="list-group-item" style="color:#999999">
					<p id="w1">
					   <b>·</b>
					  《<a href="http://www.csdn.net/article/1970-01-01/2825439" target="_blank">Vue.js：轻量高效的前端组件化方案</a>》
					</p>
					<p id="w1">
					   <b>·</b>
					  《Vue.js 和 Webpack》(<a href="http://djyde.github.io/2015/08/29/vuejs-and-webpack-1.html" target="_blank">一</a>)(<a href="http://djyde.github.io/2015/08/29/vuejs-and-webpack-2.html" target="_blank">二</a>)(<a href="http://djyde.github.io/2015/08/29/vuejs-and-webpack-3.html" target="_blank">三</a>)
					</p>
					<p id="w1">
					   <b>·</b>
					  《<a href="http://teahour.fm/2015/08/16/vuejs-creator-evan-you.html" target="_blank">尤小右采访</a>》作者的采访有一些设计理念
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://www.alloyteam.com/2015/06/mvvm-xue-xi-vue-shi-jian-xiao-jie/" target="_blank">腾讯全端 AlloyTeam 团队《mvvm学习&amp;vue实践小结》</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://jiongks.name/blog/just-vue/" target="_blank">Vue + webpack 项目实践</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://jiongks.name/blog/vue-code-review/" target="_blank">Vue.js 源码学习笔记</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="https://github.com/vingojw/vue-vueRouter-webpack/blob/master/Vue%E6%95%99%E7%A8%8B.md" target="_blank">Vue教程</a>
					</p>
					<h3 style="font-weight:bold;color:black;margin-bottom:0.3125rem;margin-top:3.125rem">项目</h3>
				</div>
				<div class="list-group-item" style="color:#999999">
					<p id="w1">
					   <b>·</b>
					  《<a href="https://github.com/zerqu/qingcheng" target="_blank">青城主题</a>》
					</p>
					<p id="w1">
					   <b>·</b>
					  《<a href="https://github.com/shinygang/Vue-cnodejs" target="_blank">Cnodejs.org社区webapp</a>》
					</p>
					<p id="w1">
					   <b>·</b>
					  《<a href="https://github.com/vingojw" target="_blank">vingojw</a>/<a href="https://github.com/vingojw/vue-vueRouter-webpack" target="_blank">vue-vueRouter-webpack</a>》
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="https://github.com/viko16/vue-ghpages-blog" target="_blank">A blog based on Github pages by vue.js + webpack</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="https://github.com/vuejs/vue-hackernews" target="_blank"> HackerNews clone with Vue.js</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="http://cn.vuejs.org/examples/" target="_blank">
					   </a>
					   官方示例
					   <a href="https://github.com/vuejs/vue-hackernews" target="_blank"> HackerNews clone with Vue.js
					   </a>
					</p>
					<p id="w1">
					   <b>·</b>
					  <a href="http://jsfiddle.net/lain8dono/mrnyf79e/" target="_blank">用Vue实现的拖拽效果</a>
					</p>
					<p id="w1">
					   <b>·</b>
					  <a href="http://jsfiddle.net/lain8dono/mrnyf79e/" target="_blank">用Vue实现的拖拽效果</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="https://github.com/Coffcer/vue-chat" target="_blank">Chat by Vue + Webpack</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="https://github.com/mennghao/vue-mui" target="_blank">vue-mui</a>
					</p>
					<h3 style="font-weight:bold;color:black;margin-bottom:0.3125rem;margin-top:3.125rem">视频</h3>
				</div>
				<div class="list-group-item" style="color:#999999">
					<p id="w1">
					   <b>·</b>
					   <a href="http://www.imooc.com/video/6346" target="_blank">尤小右分享vuejs 数据驱动的组件化前端开发</a>
					</p>
					<p id="w1">
					   <b>·</b>
					  <a href="https://laracasts.com/series/learning-vue-step-by-step" target="_blank">laracasts.com Vuejs1.0教程</a>
					</p>
					<h3 style="font-weight:bold;color:black;margin-bottom:0.3125rem;margin-top:3.125rem">技术交流</h3>
				</div>
				<div class="list-group-item" style="color:#999999">
					<p id="w1">
					   <b>·</b>
					   <a href="https://gitter.im/vuejs/vue" target="_blank">Vue的聊天室</a>
					</p>
					<p id="w1">
					   <b>·</b>
					   <a href="https://twitter.com/vuejs" target="_blank">Vuejs官方推特</a>
					</p>
					<p style="color:black;margin-top:0.625rem">资料来自：Vue qq群（516483308）</p>
					
				</div>
		    </div>
		</div>
	</div>
</template>
<style>
	#zy>a{
		color:green;
	}
	#tiao>span{
		margin:0 0.1875rem;
	}
	#w1{
		margin:0.3125rem;
	}
	#w1>a{
		color:#999999;
	}

</style>
<script>
	
</script>