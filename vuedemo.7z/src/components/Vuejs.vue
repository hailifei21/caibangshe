<template>
	<div class="container-fuliter">
		
	</div>
</template>
<style>
	*{
		margin:0;
		padding:0;
	}
	#show{
		background:white;
	}
</style>
<script>

</script>